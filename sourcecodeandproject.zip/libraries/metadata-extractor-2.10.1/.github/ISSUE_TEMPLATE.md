(Please include as much information as possible, and attach a sample image if possible.)
