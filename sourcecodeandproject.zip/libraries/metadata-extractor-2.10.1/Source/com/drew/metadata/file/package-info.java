/**
 * Contains classes for the extraction and modelling of file system metadata.
 *
 * @since 2.8.0
 */
package com.drew.metadata.file;
