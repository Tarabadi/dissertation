/**
 * Contains classes for working with PCX image files.
 */
package com.drew.imaging.pcx;
