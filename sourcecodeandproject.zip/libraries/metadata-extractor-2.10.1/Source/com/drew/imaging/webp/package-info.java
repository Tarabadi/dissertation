/**
 * Contains classes for working with WebP format files.
 */
package com.drew.imaging.webp;
